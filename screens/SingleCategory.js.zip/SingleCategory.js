import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  TouchableOpacity,
  Text,
  FlatList,
  Platform,
  SafeAreaView,
  TextInput,
  Image,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {openDatabase} from 'react-native-sqlite-storage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {AdMobRewarded} from 'react-native-admob';
import Modal from 'react-native-modal';
import PopModelView from './components/PopModelView';
import Icon from 'react-native-vector-icons/Ionicons';
import LightIcon from 'react-native-vector-icons/Entypo';
import BrushIcon from 'react-native-vector-icons/Entypo';
import CoinIcon from 'react-native-vector-icons/FontAwesome5';
import CloseIcon from 'react-native-vector-icons/FontAwesome';
import PlayIcon from 'react-native-vector-icons/SimpleLineIcons';
import LinearGradient from 'react-native-linear-gradient';
import PopOver, {PopoverPlacement} from 'react-native-popover-view';
import ConfettiAnimation from './components/ConfettiAnimation';

var db = openDatabase({
  name: 'Riddles.db',
  createFromLocation: 1,
});

const SingleCategory = ({navigation, route}) => {
  const {tableName} = route.params;
  const [riddleData, setRiddleData] = useState([{riddle: ''}]);
  const [text, setText] = useState([]);
  const [isModalVisible, setModalVisible] = useState(false);
  const [isPressedOkay, setPressedOkay] = useState(false);
  const [isLevelcomplete, setLevelCpmplete] = useState(false);
  const [counter, setCounter] = useState(0);
  const [revealCounter, setRevealCounter] = useState(0);
  const [RevealLetter, setRevealLetter] = useState([]);
  const [isRewardVisible, setRewardVisible] = useState(false);
  const [isFlagVisible, setFlagVisible] = useState(false);
  const [isHintVisible, setHintVisible] = useState(false);
  const [coins, setCoins] = useState(100);
  const [textans, setTextAns] = useState([]);
  const [isVisible, setVisible] = useState(false);
  const [helpModal, setHelpModal] = useState(false);
  const [hide, setHide] = useState([]);
  const [riddle, setRiddle] = useState();

  //----------------------USE EFFECT--------------------------
  useEffect(() => {
    getRiddleData();
  }, [counter]);

  useEffect(() => {
    randomCharacter();
  }, [counter]);

  useEffect(() => {
    AdMobRewarded.addEventListener('adClosed', () => {
      console.log('AdMobRewarded => adClosed');
      setRewardVisible(true);
    });
  }, []);

  var newLevel;
  var keypad = [];

  const videoAds = () => {
    setVisible(false);
    AdMobRewarded.setAdUnitID('ca-app-pub-3940256099942544/5224354917');
    AdMobRewarded.requestAd().then(() => AdMobRewarded.showAd());
  };

  const randomCharacter = () => {
    const answer = `${riddle && riddle.answer}`;
    const separatedComma = Array.from(answer).toString().replace(/,/g, '');

    keypad = separatedComma.split('');
    var totalRandom = 14 - keypad.length;
    var result = '';
    var characters = 'abcdefghijklmnopqrstuvwxyz';
    var charactersLength = characters.length;
    for (var i = 0; i < totalRandom; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    const newKeypad = result.split('');
    const finalKeypad = keypad.concat(newKeypad).sort();
    setTextAns(finalKeypad);
  };

  const strWithoutComma = text.toString().replace(/,/g, '');
  // console.log('string without comma', strWithoutComma);

  const revel = RevealLetter.concat(text);
  const revelStr = revel.toString().replace(/,/g, '');

  //----------------GET CURRENT RIDDLE INDEX---------------------
  const getIndex = async () => {
    if (isLevelcomplete === true) {
      // let newCounter = await AsyncStorage.getItem('CurrentLevel');
      // let index = Number(newCounter);

      // if (index > 1) {
      //   await AsyncStorage.setItem('CurrentLevel', (counter + 1).toString());
      //   await AsyncStorage.setItem('COINS', (coins + 250).toString());
      // } else {
      //   // setCounter(counter + 1);
      //   await AsyncStorage.setItem('CurrentLevel', (counter + 1).toString());
      //   await AsyncStorage.setItem('COINS', (coins + 250).toString());
      // }

      // let level = await AsyncStorage.getItem('CurrentLevel');
      // let coin = await AsyncStorage.getItem('COINS');
      // setCoins(Number(coin));
      // setCounter(Number(level));

      getRiddleData();

      RevealLetter.length = 0;
      setText('');
      setHide('');
      setLevelCpmplete(false);
      setHintVisible(false);
    }
  };

  //----------------CURRENT LEVEL COUNTER---------------------
  const getCurrentLevel = async () => {
    newLevel = await AsyncStorage.getItem('CurrentLevel');
    let index = Number(newLevel);
    if (index > 1) {
      getRiddleData();
      let coin = await AsyncStorage.getItem('COINS');
      setCoins(Number(coin));
    } else {
      getRiddleData();
    }
  };

  //---------------REVEAL INDEX------------------------
  const revealIndex = async () => {
    const answer = `${riddle && riddle.answer}`;
    const separatedComma = Array.from(answer).toString().replace(/,/g, '');
    setRevealCounter(revealCounter + 1);
    setRevealLetter([...RevealLetter, separatedComma[revealCounter]]);
    await AsyncStorage.setItem('COINS', (coins - 50).toString());
    let coin = await AsyncStorage.getItem('COINS');
    setCoins(Number(coin));
    setVisible(false);
  };

  //----------------REMOVE LAST LETTER---------------------
  const removeLast = () => {
    let arr = text.splice(-1);
    setText(text.filter((item) => item !== arr));
    hide.pop();
    setHide(hide);
  };

  //----------------REMOVE PARTICULAR LETTER---------------------
  const removeParticular = (i) => {
    let arr = text.splice(i);
    setText(text.filter((item) => item != arr));
  };

  //-------------------------------------
  const toggleModal = () => {
    if (isHintVisible == false) {
      setVisible(false);
      setModalVisible(!isModalVisible);
      setHintVisible(true);
    }
  };

  //-------------------------------------
  const rewardModel = () => {
    if (isFlagVisible == false && isPressedOkay == false) {
      setRewardVisible(!isRewardVisible);
      setFlagVisible(true);
      setPressedOkay(true);
    }
  };

  //--------------------RIDDLES DATA----------------------
  const getRiddleData = async () => {
    let coin = await AsyncStorage.getItem('COINS');
    setCoins(Number(coin));
    var data = [];
    await db.transaction((tx) => {
      tx.executeSql('SELECT * FROM ' + tableName, [], (tx, results) => {
        var len = results.rows.length;
        for (var i = 0; i < len; i++) {
          data = [...data, results.rows.item(i)];
        }
        const completed = data.filter((item) => item.level == 'complete');
        const id = completed.length;
        setCounter(id);
        setRiddle({
          level: data[id].id,
          riddle: data[id].riddle,
          answer: data[id].answer,
        });
        setRiddleData(data);
      });
    });
  };

  //--------------------CURRENT LEVEL----------------------
  const getCurrentRiddleLevel = async () => {
    var data = [];
    var count = await AsyncStorage.getItem('CurrentLevel');
    let index = Number(count);

    await db.transaction((tx) => {
      tx.executeSql('SELECT * FROM ' + tableName, [], (tx, results) => {
        var len = results.rows.length;
        for (var i = index; i < len; i++) {
          data = [...data, results.rows.item(i)];
        }
        setRiddleData(data);
      });
    });
  };

  //----------------ADD LEVEL IN DATABASE---------------------

  const addLevel = async () => {
    try {
      await db.transaction((tx) => {
        tx.executeSql(
          `UPDATE ${tableName} set level=?  where id=?`,
          ['complete', riddle && riddle.level],
          (tx, results) => {
            if (results.rowsAffected > 0) {
              console.log('updated');
            } else console.log('Updation Failed');
          },
        );
      });
    } catch (e) {
      console.log(e);
    }
  };

  //--------------------ANSWER VIEW----------------

  const onEndEditing = () => {
    if (riddle && riddle.answer == revelStr) {
      console.log('LEVEL COMPLETE');
      setLevelCpmplete(true);
      getIndex();
      addLevel();
    } else {
      setLevelCpmplete(false);
    }
  };

  const renderItem = ({item, index}) => (
    <TouchableOpacity
      style={{
        ...styles.AnswerFillView,
        backgroundColor:
          riddle && riddle.answer == revelStr
            ? '#3CB371'
            : riddle &&
              riddle.answer.length == revelStr.length &&
              riddle &&
              riddle.answer != revelStr
            ? 'red'
            : '#708090',
      }}>
      <TextInput
        style={{
          fontSize: 20,
          fontWeight: 'bold',
          textTransform: 'uppercase',
          color: '#fff',
        }}
        maxLength={1}
        value={text ? revelStr[index] : ''}
        onEndEditing={onEndEditing()}
      />
    </TouchableOpacity>
  );

  const Button = ({icon, tittle, onPress, disabled, coin, coins}) => (
    <TouchableOpacity
      disabled={disabled}
      style={{
        ...styles.ButtonView,
        backgroundColor: disabled ? '#228B22' : '#3CB371',
      }}
      onPress={onPress}>
      <View style={{flexDirection: 'row'}}>
        <Image source={icon} style={{height: hp(3), width: hp(3)}} />
        <Text style={styles.ButtonText}>{tittle}</Text>
      </View>
      {coin && (
        <View style={{flexDirection: 'row'}}>
          <Image source={coin} style={{height: hp(2.5), width: hp(2.5)}} />
          <Text style={styles.ButtonText}>{coins}</Text>
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView>
      <View style={styles.mainContainer}>
        <View style={styles.topHeaderContainer}>
          <TouchableOpacity
            style={styles.backButtonContainer}
            onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={30} style={styles.closeIconStyle} />
          </TouchableOpacity>

          <View style={styles.scoreViewStyle}>
            <LinearGradient
              colors={['#9370DB', '#FFC0CB', '#FFFF00']}
              start={{x: 0, y: 0}}
              end={{x: 1, y: 0}}
              style={{borderRadius: 20}}>
              <View style={styles.mainScoreViewstyle}>
                <Text style={styles.scoreTextStyle}>
                  {/* {counter && riddleData[counter].id} */}
                  {riddle && riddle.level}
                </Text>
              </View>
            </LinearGradient>
          </View>

          <PopOver
            placement={PopoverPlacement.CENTER}
            from={
              <TouchableOpacity style={styles.coinContainer}>
                <CoinIcon.Button
                  name="coins"
                  backgroundColor="#008B8B"
                  size={20}>
                  <Text style={styles.coinText}>{coins}</Text>
                </CoinIcon.Button>
              </TouchableOpacity>
            }>
            <View style={styles.mainPopContainer}>
              <CloseIcon
                name="remove"
                size={20}
                style={styles.closeIconStyle}
              />
              <Text style={styles.headingStyle}>Store</Text>
              {/* <TouchableOpacity style={styles.popButtonStyle}>
                <Text>Watch</Text>
              </TouchableOpacity> */}
              <PlayIcon.Button
                name="social-youtube"
                backgroundColor="#3b5998"
                style={
                  isPressedOkay == true
                    ? styles.PopButtonPressed
                    : styles.popButtonStyle
                }
                onPress={() => navigation.navigate('Video')}>
                Watch
              </PlayIcon.Button>

              <PopModelView
                isModelVisible={isRewardVisible}
                title="Reward"
                messege="You succesfully topped up your balance and received 20 coins."
                okayButtonText="Okay"
                onOkay={() => setRewardVisible(false)}
              />
            </View>
          </PopOver>
        </View>

        <View style={styles.riddleContainer}>
          {/* <Text style={styles.textStyle}>{riddleData[counter].riddle}</Text> */}
          <Text style={styles.textStyle}>{riddle && riddle.riddle}</Text>
        </View>
        {/* {isLevelcomplete && <ConfettiAnimation />} */}
        <View style={styles.flatview}>
          <FlatList
            numColumns={7}
            contentContainerStyle={{margin: 4}}
            scrollEnabled={false}
            removeClippedSubviews={false}
            // data={riddleData[counter].answer}
            data={riddle && riddle.answer}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
          />
        </View>

        <View style={styles.buttonsContainer}>
          <FlatList
            keyExtractor={(index) => index.toString()}
            scrollEnabled={false}
            numColumns={7}
            contentContainerStyle={{margin: 4}}
            data={textans}
            renderItem={({item, index}) => {
              return (
                <TouchableOpacity
                  disabled={hide.includes(index)}
                  style={{
                    ...styles.touchableViewStyle,
                    backgroundColor: hide.includes(index) ? '#5A5A5A' : '#fff',
                  }}
                  onPress={() => {
                    setText([...text, item]);
                    setHide([...hide, index]);
                  }}>
                  <Text style={styles.bottomContTextStyle}> {item} </Text>
                </TouchableOpacity>
              );
            }}
          />
          <View style={{flexDirection: 'row'}}>
            <TouchableOpacity
              style={styles.touchableButtonStyle}
              onPress={() => setVisible(true)}>
              <LightIcon name="light-bulb" size={20} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.touchableButtonStyle}
              onPress={() => removeLast()}>
              <BrushIcon name="flat-brush" size={20} />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <Modal
        isVisible={isVisible}
        animationIn="wobble"
        animationOut="slideOutDown">
        <View
          style={{
            backgroundColor: '#3b5998',
            width: wp(70),
            paddingBottom: hp(2),
            borderRadius: 10,
            alignSelf: 'center',
          }}>
          <TouchableOpacity
            onPress={() => setVisible(false)}
            style={{
              alignSelf: 'flex-end',
              marginTop: hp(1),
              marginRight: hp(1),
            }}>
            <CloseIcon name="remove" size={20} style={styles.closeIconStyle} />
          </TouchableOpacity>
          <Text style={styles.headingStyle}>Boosts</Text>
          <Button
            icon={require('../asset/help.png')}
            tittle="Ask Friends for Help"
            onPress={() => setHelpModal(true)}
          />
          <Button
            icon={require('../asset/world.png')}
            tittle="Reveal Letter"
            coin={require('../asset/coin.png')}
            coins="50"
            onPress={() => {
              revealIndex();
            }}
          />
          <Button
            icon={require('../asset/delete.png')}
            tittle="Remove Letters"
            coin={require('../asset/coin.png')}
            coins="80"
          />
          <Button
            disabled={isHintVisible}
            icon={require('../asset/idea.png')}
            tittle="Show Hint"
            coin={require('../asset/coin.png')}
            coins="100"
            onPress={() => toggleModal()}
          />
          <Button
            icon={require('../asset/youtube.png')}
            tittle="Recevoir 50 Pieces"
            onPress={() => videoAds()}
          />
        </View>
      </Modal>
      <Modal
        isVisible={helpModal}
        animationIn="wobble"
        animationOut="slideOutDown">
        <View
          style={{
            backgroundColor: '#3b5998',
            width: wp(70),
            paddingBottom: hp(2),
            borderRadius: 10,
            alignSelf: 'center',
          }}>
          <TouchableOpacity
            onPress={() => setHelpModal(false)}
            style={{
              alignSelf: 'flex-end',
              marginTop: hp(1),
              marginRight: hp(1),
            }}>
            <CloseIcon name="remove" size={20} style={styles.closeIconStyle} />
          </TouchableOpacity>
          <Text style={styles.headingStyle}>Ask Friends for Help</Text>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: wp(6),
              marginVertical: hp(3),
            }}>
            <TouchableOpacity>
              <Image
                source={require('../asset/instagram.png')}
                style={{height: hp(7), width: hp(7)}}
              />
            </TouchableOpacity>
            <TouchableOpacity>
              <Image
                source={require('../asset/sms.png')}
                style={{height: hp(7), width: hp(7)}}
              />
            </TouchableOpacity>
            <TouchableOpacity>
              <Image
                source={require('../asset/mail.png')}
                style={{height: hp(7), width: hp(7)}}
              />
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      <PopModelView
        isModelVisible={isModalVisible}
        title="Hint"
        messege={riddle && riddle.answer}
        okayButtonText="Okay"
        onOkay={async () => {
          await AsyncStorage.setItem('COINS', (coins - 100).toString());
          let coin = await AsyncStorage.getItem('COINS');
          setCoins(Number(coin));
          setModalVisible(!isModalVisible);
        }}
      />
      <PopModelView
        isModelVisible={isRewardVisible}
        title="Reward"
        messege="You succesfully topped up your balance and received 50 coins."
        okayButtonText="Okay"
        onOkay={async () => {
          await AsyncStorage.setItem('COINS', (coins + 50).toString());
          let coin = await AsyncStorage.getItem('COINS');
          setCoins(Number(coin));
          setRewardVisible(false);
        }}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    //flex: 1,
    height: '100%',
    backgroundColor: '#e9e6f2',
  },

  // Top Header Style
  topHeaderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Platform.OS === 'ios' ? 35 : 10,
    backgroundColor: '#e9e6f2',
  },

  backButtonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: wp('25%'),
    height: hp('7%'),
    backgroundColor: '#008B8B', //#3CB371
    borderTopRightRadius: 50,
    borderBottomRightRadius: 50,
  },

  backText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
  },
  coinContainer: {
    width: wp('25%'),
    height: hp('7%'),
    backgroundColor: '#008B8B',
    borderTopLeftRadius: 50,
    borderBottomLeftRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },

  coinText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
  },

  // Riddle Style
  riddleContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e9e6f2',
    padding: 20,
  },

  riddleText: {
    fontSize: 16,
    textAlign: 'center',
  },

  // TextInput
  textInput: {
    borderWidth: 2,
    borderColor: '#ccc',
    margin: 20,
    borderRadius: 10,
  },

  // Bottom Button Style
  buttonsContainer: {
    backgroundColor: '#778899',
    height: hp(25),
    alignItems: 'center',
    // backgroundColor: '#778899', //'#a4a5b4',
    // padding: Platform.OS === 'ios' ? 10 : 5,
    // height: Platform.OS === 'ios' ? hp('8%') : hp['10%'],
    // width: wp('100%'),
  },

  answerContainer: {
    alignItems: 'center',
    backgroundColor: 'lightgray', //'#a4a5b4',
    padding: 10,
  },

  latterStyle: {
    color: '#000',
    backgroundColor: 'lightgray',
  },

  touchableViewStyle: {
    margin: hp(1),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 1,
      height: 1,
    },
    elevation: 2,
    shadowOpacity: 1.0,
    height: hp(6),
    width: hp(6),
  },

  selectedText: {
    backgroundColor: '#778899',
    marginHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 1,
      height: 1,
    },
    elevation: 2,
    shadowOpacity: 1.0,
    height: 50,
    width: 30,
  },

  touchableButtonStyle: {
    backgroundColor: '#008B8B',
    marginHorizontal: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 1,
      height: 1,
    },
    elevation: 2,
    shadowOpacity: 1.0,
    height: hp(6),
    width: hp(7),
    marginBottom: hp(2),
  },

  AnswerView: {
    backgroundColor: 'white',
    marginHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    elevation: 4,
    margin: 5,
    shadowOpacity: 1.0,
    height: hp(6),
    width: hp(6),
  },

  AnswerFillView: {
    margin: 5,
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 20,
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    elevation: 4,
    shadowOpacity: 1.0,
    height: hp(6),
    width: hp(6),
  },

  BlankSpace: {
    backgroundColor: 'blue',
  },

  bottomContTextStyle1: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
  },
  bottomContTextStyle: {
    textTransform: 'uppercase',
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
  },

  textStyle: {
    fontSize: 20,
    textAlign: 'center',
    fontWeight: 'bold',
    marginHorizontal: 50,
  },

  answerContainerView: {
    backgroundColor: '#e9e6f2',
    bottom: 40,
    alignItems: 'center',
  },
  trashButton: {
    backgroundColor: '#3CB371',
    marginHorizontal: 10,
    paddingVertical: 15,
    alignItems: 'center',
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 1.0,
    height: 50,
    width: 30,
  },
  touchableTextStyle: {
    backgroundColor: 'darkgray',
    marginHorizontal: 10,
    paddingVertical: 15,
    alignItems: 'center',
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 1.0,
    height: 50,
    width: 30,
  },

  scoreViewStyle: {
    height: 70,
    width: 70,
    backgroundColor: '#008B8B',
    borderRadius: 25,
    borderColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },

  mainScoreViewstyle: {
    height: 60,
    width: 60,
    borderWidth: 2,
    borderColor: '#fff',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },

  scoreTextStyle: {
    fontSize: 30,
    color: '#fff',
  },

  headingStyle: {
    fontSize: 20,
    color: '#fff',
    alignSelf: 'center',
  },

  closeIconStyle: {
    color: '#fff',
  },

  mainPopContainer: {
    justifyContent: 'flex-start',
    backgroundColor: '#3b5998',
    width: 250,
  },

  popButtonStyle: {
    backgroundColor: '#3CB371',
    borderRadius: 18,
    margin: 5,
  },

  PopButtonPressed: {
    backgroundColor: '#228B22',
    borderRadius: 18,
    margin: 5,
  },

  RewardStyle: {
    fontSize: 20,
    color: '#fff',
    alignSelf: 'center',
    marginTop: 10,
    marginHorizontal: 20,
    textAlign: 'center',
  },

  ButtonView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 18,
    width: wp(60),
    alignSelf: 'center',
    margin: hp(1),
    padding: hp(1.2),
  },

  TouchableButton: {
    flexDirection: 'row',
    backgroundColor: '#228B22',
    borderRadius: 18,
    margin: 5,
    justifyContent: 'space-between',
    padding: 8,
  },

  ButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent: 'flex-start',
    marginLeft: 5,
  },

  coinTextStyle: {
    color: '#fff',
  },

  coinView: {
    alignSelf: 'flex-end',
    flexDirection: 'row',
    marginLeft: 70,
  },

  coinView1: {
    alignSelf: 'flex-end',
    flexDirection: 'row',
    marginLeft: 50,
  },

  item: {
    // backgroundColor: '#f9c2ff',
    padding: 2,
    //width:10,
    //marginVertical: 8,
    borderRadius: 10,
    //marginHorizontal: 10,
    marginBottom: 30,
  },

  flatview: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: hp(10),
  },
});

export default SingleCategory;
